<?php
require_once '../includes/init.php';
requireProfessor();

header('Location: ./my_sections.php');
exit;
