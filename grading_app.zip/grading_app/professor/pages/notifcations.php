<?php
require_once '../includes/init.php';
requireProfessor();

header('Location: ./notifications.php');
exit;
