<footer style="padding:16px;color:#98a2b3;">
  <small>PTC professor Portal</small>
</footer>
