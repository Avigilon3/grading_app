<head>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>


<aside class="sidebar">
  <nav class="sidebar-nav">
    <a href="./dashboard.php" class="nav-item">
      <span class="material-symbols-rounded">dashboard</span>
        Dashboard</a>
    <a href="./my_sections.php" class="nav-item">
      <span class="material-symbols-rounded">database</span>
        My Sections</a>
    <a href="./grading_sheet.php" class="nav-item">
      <span class="material-symbols-rounded">stacks</span>
        Grading Sheets</a>
    <a href="./requests.php" class="nav-item">
      <span class="material-symbols-rounded">error</span>
        Requests</a>
  </nav>
</aside>
