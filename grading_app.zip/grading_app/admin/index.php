<?php
require_once '../core/config/config.php';
header('Location: pages/dashboard.php'); 
exit;
    