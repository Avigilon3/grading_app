<?php   
// grading_app/admin/includes/auth.php
// Module-specific auth helpers can go here, dependencies loaded by includes/init.php

