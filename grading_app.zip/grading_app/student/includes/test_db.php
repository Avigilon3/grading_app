<?php
require 'db.php'; // same folder as db.php

echo "Connected to the database successfully!";
?>
