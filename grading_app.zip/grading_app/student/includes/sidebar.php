<head>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>


<aside class="sidebar">
  <nav class="sidebar-nav">
    <a href="../pages/dashboard.php" class="nav-item">
      <span class="material-symbols-rounded">dashboard</span>
        Dashboard</a>
    <a href="../pages/subjects.php" class="nav-item">
      <span class="material-symbols-rounded">database</span>
        Subjects</a>
    <a href="../pages/report_of_grades.php" class="nav-item">
      <span class="material-symbols-rounded">stacks</span>
        Report of Grades</a>
    <a href="../pages/requests.php" class="nav-item">
      <span class="material-symbols-rounded">error</span>
        Requests</a>
  </nav>
</aside>
